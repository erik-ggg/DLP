package ast.statements;

import ast.main.ASTNode;

public interface Statement extends ASTNode {

}
